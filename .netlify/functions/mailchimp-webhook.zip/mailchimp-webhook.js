// Mailchimp Email Automation Webhook
// Handles email signups and integrates with Mailchimp API

exports.handler = async (event, context) => {
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Allow': 'POST',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { email, source, inquiry_type, name, custom_fields, interests } = JSON.parse(event.body);
    
    // Validate required fields
    if (!email || !source) {
      return {
        statusCode: 400,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ 
          error: 'Missing required fields: email and source' 
        })
      };
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return {
        statusCode: 400,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'Invalid email format' })
      };
    }

    // Determine tags and interest groups based on source
    const mailchimpConfiguration = {
      'appfinder': {
        tags: ['appfinder-interest', 'mobile-app', 'website-signup'],
        interests: ['mobile-apps', 'pre-launch'],
        status: 'subscribed'
      },
      'etsy-shop': {
        tags: ['etsy-customer', 'shop-interest', 'website-signup'],
        interests: ['etsy-shop', 'products'],
        status: 'subscribed'
      },
      'newsletter': {
        tags: ['newsletter', 'general-interest', 'website-signup'],
        interests: ['newsletter', 'updates'],
        status: 'subscribed'
      },
      'contact': {
        tags: ['contact-form', 'website-signup', inquiry_type || 'general'],
        interests: ['contact', 'support'],
        status: 'subscribed'
      }
    };

    const config = mailchimpConfiguration[source] || mailchimpConfiguration['newsletter'];

    // Prepare Mailchimp subscriber data
    const subscriberData = {
      email_address: email,
      status: config.status,
      merge_fields: {
        FNAME: name || '',
        SOURCE: source.toUpperCase(),
        SIGNUP: new Date().toISOString().split('T')[0] // YYYY-MM-DD format
      },
      tags: config.tags
    };

    // Add custom fields if provided
    if (custom_fields) {
      Object.keys(custom_fields).forEach(key => {
        // Mailchimp merge field names must be uppercase and max 10 chars
        const mcKey = key.toUpperCase().substring(0, 10);
        subscriberData.merge_fields[mcKey] = custom_fields[key];
      });
    }

    // Add interests if provided
    if (interests && Array.isArray(interests)) {
      subscriberData.tags = [...subscriberData.tags, ...interests];
    }

    // Add inquiry type for contact forms
    if (inquiry_type) {
      subscriberData.merge_fields.INQUIRY = inquiry_type;
    }

    // Get Mailchimp credentials from environment
    const apiKey = process.env.MAILCHIMP_API_KEY;
    const audienceId = process.env.MAILCHIMP_AUDIENCE_ID;
    const serverPrefix = apiKey ? apiKey.split('-')[1] : 'us1';

    if (!apiKey || !audienceId) {
      throw new Error('Mailchimp API credentials not configured');
    }

    // Add subscriber to Mailchimp
    const mailchimpUrl = `https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members`;
    
    const mailchimpResponse = await fetch(mailchimpUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(subscriberData)
    });

    const mailchimpData = await mailchimpResponse.json();

    // Handle existing subscriber (400 error)
    if (mailchimpResponse.status === 400 && mailchimpData.title === 'Member Exists') {
      // Update existing subscriber with new tags
      const updateUrl = `https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${email}`;
      
      const updateResponse = await fetch(updateUrl, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          merge_fields: subscriberData.merge_fields,
          tags: config.tags
        })
      });

      if (updateResponse.ok) {
        const updateData = await updateResponse.json();
        mailchimpData.id = updateData.id;
        mailchimpData.status = 'updated';
      }
    } else if (!mailchimpResponse.ok) {
      console.error('Mailchimp API error:', mailchimpData);
      throw new Error(`Mailchimp API error: ${mailchimpResponse.status} - ${mailchimpData.detail || mailchimpData.title}`);
    }

    // Trigger marketing automation workflow if configured
    if (process.env.MARKETING_AUTOMATION_WEBHOOK) {
      fetch(process.env.MARKETING_AUTOMATION_WEBHOOK, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'new_subscriber',
          subscriber: {
            email: email,
            name: name,
            source: source,
            mailchimp_subscriber_id: mailchimpData.id,
            tags: config.tags,
            status: mailchimpData.status || 'subscribed'
          },
          timestamp: new Date().toISOString()
        })
      }).catch(err => console.log('Marketing automation webhook failed:', err));
    }

    // Enhanced analytics tracking
    const analyticsEvent = {
      event_name: 'email_signup',
      parameters: {
        source: source,
        inquiry_type: inquiry_type,
        timestamp: new Date().toISOString(),
        mailchimp_subscriber_id: mailchimpData.id,
        email_provider: 'mailchimp'
      }
    };

    // Track the analytics event
    if (process.env.NODE_ENV !== 'test') {
      try {
        await fetch(`${event.headers.origin || 'https://staging-untrapd-hub.netlify.app'}/api/analytics-api/track-event`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(analyticsEvent)
        });
      } catch (analyticsError) {
        console.log('Analytics tracking failed:', analyticsError);
      }
    }

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: true,
        message: 'Successfully subscribed to email list',
        subscriber_id: mailchimpData.id,
        status: mailchimpData.status || 'subscribed',
        tags: config.tags,
        analytics: analyticsEvent,
        provider: 'mailchimp'
      })
    };

  } catch (error) {
    console.error('Mailchimp webhook error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: process.env.NODE_ENV === 'production' ? 
          'Something went wrong' : error.message,
        provider: 'mailchimp'
      })
    };
  }
};