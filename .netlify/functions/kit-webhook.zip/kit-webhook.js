// Kit Email Automation Webhook
// Handles email signups and integrates with marketing automation system

exports.handler = async (event, context) => {
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers: {
        'Allow': 'POST',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const { email, source, inquiry_type, name, custom_fields } = JSON.parse(event.body);
    
    // Validate required fields
    if (!email || !source) {
      return {
        statusCode: 400,
        body: JSON.stringify({ 
          error: 'Missing required fields: email and source' 
        })
      };
    }

    // Determine Kit form/tag based on source
    const kitConfiguration = {
      'appfinder': {
        tags: ['appfinder-interest', 'mobile-app'],
        form_id: process.env.KIT_APPFINDER_FORM_ID,
        follow_up: 'appfinder_welcome_sequence'
      },
      'etsy-shop': {
        tags: ['etsy-customer', 'shop-interest'],
        form_id: process.env.KIT_SHOP_FORM_ID,
        follow_up: 'shop_welcome_sequence'
      },
      'newsletter': {
        tags: ['newsletter', 'general-interest'],
        form_id: process.env.KIT_NEWSLETTER_FORM_ID,
        follow_up: 'general_welcome_sequence'
      },
      'contact': {
        tags: ['contact-form', inquiry_type || 'general'],
        form_id: process.env.KIT_CONTACT_FORM_ID,
        follow_up: 'contact_follow_up'
      }
    };

    const config = kitConfiguration[source] || kitConfiguration['newsletter'];

    // Add subscriber to Kit
    const kitResponse = await fetch(`${process.env.KIT_API_URL}/subscribers`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.KIT_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email_address: email,
        first_name: name,
        tags: config.tags,
        custom_fields: {
          source: source,
          signup_date: new Date().toISOString(),
          inquiry_type: inquiry_type,
          ...custom_fields
        }
      })
    });

    if (!kitResponse.ok) {
      throw new Error(`Kit API error: ${kitResponse.status}`);
    }

    const kitData = await kitResponse.json();

    // Trigger marketing automation workflow
    if (process.env.MARKETING_AUTOMATION_WEBHOOK) {
      await fetch(process.env.MARKETING_AUTOMATION_WEBHOOK, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'new_subscriber',
          subscriber: {
            email: email,
            name: name,
            source: source,
            kit_subscriber_id: kitData.subscriber.id,
            tags: config.tags
          },
          timestamp: new Date().toISOString()
        })
      }).catch(err => console.log('Marketing automation webhook failed:', err));
    }

    // Enhanced analytics tracking
    const analyticsEvent = {
      event_name: 'email_signup',
      parameters: {
        source: source,
        inquiry_type: inquiry_type,
        timestamp: new Date().toISOString(),
        kit_subscriber_id: kitData.subscriber.id
      }
    };

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        success: true,
        message: 'Successfully subscribed to email list',
        subscriber_id: kitData.subscriber.id,
        follow_up: config.follow_up,
        analytics: analyticsEvent
      })
    };

  } catch (error) {
    console.error('Kit webhook error:', error);
    
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        error: 'Internal server error',
        message: process.env.ENVIRONMENT === 'production' ? 
          'Something went wrong' : error.message
      })
    };
  }
};