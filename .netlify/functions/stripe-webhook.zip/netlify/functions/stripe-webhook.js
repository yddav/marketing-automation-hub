// Netlify Function for Stripe Webhook Automation
// Handles payment completion and automated email delivery

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event, context) => {
  // Only handle POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  const sig = event.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let stripeEvent;

  try {
    // Verify webhook signature
    stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      webhookSecret
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Webhook signature verification failed' })
    };
  }

  // Handle the checkout session completed event
  if (stripeEvent.type === 'checkout.session.completed') {
    const session = stripeEvent.data.object;
    
    console.log('Payment completed:', session.id);
    
    try {
      // Send automated delivery email
      await sendProductDeliveryEmail({
        email: session.customer_details.email,
        name: session.customer_details.name || 'Valued Customer',
        sessionId: session.id,
        amount: session.amount_total / 100,
        paymentIntent: session.payment_intent
      });
      
      // Record sale for analytics
      await recordSale({
        sessionId: session.id,
        email: session.customer_details.email,
        name: session.customer_details.name,
        amount: session.amount_total / 100,
        timestamp: new Date().toISOString(),
        paymentIntent: session.payment_intent
      });
      
      console.log('Automated delivery completed for:', session.customer_details.email);
      
    } catch (error) {
      console.error('Error processing completed payment:', error);
      
      // Return success to Stripe but log the error
      return {
        statusCode: 200,
        body: JSON.stringify({ 
          received: true, 
          error: 'Processing error logged',
          sessionId: session.id 
        })
      };
    }
  }

  return {
    statusCode: 200,
    body: JSON.stringify({ received: true })
  };
};

// Automated email delivery function
async function sendProductDeliveryEmail(customerData) {
  const emailContent = generateEmailHTML(customerData);
  
  // Using SendGrid for email delivery
  // Alternative: Mailgun, AWS SES, or other email service
  const sgMail = require('@sendgrid/mail');
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
  
  const msg = {
    to: customerData.email,
    from: {
      email: 'hello@untrapd.com',
      name: 'UntrapD Marketing Hub'
    },
    subject: '🎉 Your Marketing Hub - Instant Access Inside!',
    html: emailContent,
    text: generateEmailText(customerData)
  };
  
  try {
    await sgMail.send(msg);
    console.log('Delivery email sent to:', customerData.email);
    return true;
  } catch (error) {
    console.error('Email delivery failed:', error);
    throw error;
  }
}

// Generate email HTML content
function generateEmailHTML(customerData) {
  return `
<!DOCTYPE html>
<html>
<head>
  <title>Your Marketing Automation Hub - Instant Access!</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #f8f9fa;">
  <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 20px; text-align: center;">
    <h1 style="color: white; margin: 0; font-size: 28px;">🎉 Welcome to Marketing Hub!</h1>
    <p style="color: white; font-size: 18px; margin: 10px 0 0 0;">Your purchase was successful - here's instant access</p>
  </div>
  
  <div style="background: white; padding: 40px 20px;">
    <h2 style="color: #2c3e50;">Hi ${customerData.name}! 👋</h2>
    
    <p style="font-size: 16px; line-height: 1.6; color: #495057;">
      Thank you for purchasing the Marketing Automation Hub! Your payment of <strong>$${customerData.amount}</strong> has been processed successfully.
    </p>
    
    <div style="background: #f8f9fa; padding: 25px; border-radius: 8px; margin: 25px 0;">
      <h3 style="color: #2c3e50; margin-top: 0;">🚀 Instant Downloads</h3>
      <ul style="padding-left: 20px;">
        <li style="margin-bottom: 10px;">
          <a href="https://marketing.untrapd.com/downloads/marketing-templates-bundle.zip" style="color: #667eea; text-decoration: none; font-weight: bold;">
            📄 Complete Templates Bundle
          </a> (17+ templates for all platforms)
        </li>
        <li style="margin-bottom: 10px;">
          <a href="https://marketing.untrapd.com/downloads/analytics-dashboard.zip" style="color: #667eea; text-decoration: none; font-weight: bold;">
            📊 Analytics Dashboard
          </a> (revenue tracking tools)
        </li>
        <li style="margin-bottom: 10px;">
          <a href="https://marketing.untrapd.com/downloads/automation-scripts.zip" style="color: #667eea; text-decoration: none; font-weight: bold;">
            ⚡ Automation Scripts
          </a> (A/B testing framework)
        </li>
        <li style="margin-bottom: 10px;">
          <a href="https://marketing.untrapd.com/downloads/commercial-license.pdf" style="color: #667eea; text-decoration: none; font-weight: bold;">
            📋 Commercial License
          </a> (unlimited use rights)
        </li>
      </ul>
    </div>
    
    <div style="background: #e8f5e8; padding: 25px; border-radius: 8px; margin: 25px 0;">
      <h3 style="color: #2c3e50; margin-top: 0;">🎯 Quick Start Guide</h3>
      <ol style="padding-left: 20px;">
        <li style="margin-bottom: 8px;">Download all files above</li>
        <li style="margin-bottom: 8px;">Read the Quick Start PDF in the templates bundle</li>
        <li style="margin-bottom: 8px;">Customize templates with your app details</li>
        <li style="margin-bottom: 8px;">Launch your first marketing campaign</li>
        <li style="margin-bottom: 8px;">Track performance with the analytics dashboard</li>
      </ol>
    </div>
    
    <div style="background: #fff3cd; padding: 25px; border-radius: 8px; margin: 25px 0;">
      <h3 style="color: #856404; margin-top: 0;">💡 Pro Tips</h3>
      <ul style="padding-left: 20px; color: #856404;">
        <li style="margin-bottom: 8px;">Start with social media templates for quick wins</li>
        <li style="margin-bottom: 8px;">A/B test your app store descriptions first</li>
        <li style="margin-bottom: 8px;">Set up email sequences for user retention</li>
        <li style="margin-bottom: 8px;">Use analytics dashboard to track what's working</li>
      </ul>
    </div>
    
    <div style="text-align: center; margin: 30px 0;">
      <a href="https://marketing.untrapd.com/success.html?session=${customerData.sessionId}" 
         style="background: #667eea; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
        🎯 Access Customer Portal
      </a>
    </div>
    
    <hr style="border: none; border-top: 1px solid #eee; margin: 30px 0;">
    
    <h3 style="color: #2c3e50;">📞 Need Help?</h3>
    <p style="color: #495057;">Questions? Issues? We're here to help!</p>
    <ul style="color: #495057;">
      <li>Email: <a href="mailto:hello@untrapd.com" style="color: #667eea;">hello@untrapd.com</a></li>
      <li>Response time: Usually within 4-6 hours</li>
      <li>Refund policy: 30-day money-back guarantee</li>
    </ul>
    
    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 25px 0; text-align: center;">
      <p style="margin: 0; color: #495057;"><strong>🛡️ Your Purchase Details</strong></p>
      <p style="margin: 10px 0 0 0; color: #6c757d; font-size: 14px;">
        Order ID: ${customerData.sessionId}<br>
        Amount: $${customerData.amount}<br>
        Date: ${new Date().toLocaleDateString()}
      </p>
    </div>
    
    <p style="font-size: 12px; color: #6c757d; text-align: center; margin-top: 30px;">
      This email was sent because you purchased the Marketing Automation Hub.<br>
      UntrapD | https://marketing.untrapd.com | hello@untrapd.com
    </p>
  </div>
</body>
</html>
  `;
}

// Generate plain text email content
function generateEmailText(customerData) {
  return `
Hi ${customerData.name}!

Thank you for purchasing the Marketing Automation Hub! Your payment of $${customerData.amount} has been processed successfully.

INSTANT DOWNLOADS:
- Complete Templates Bundle: https://marketing.untrapd.com/downloads/marketing-templates-bundle.zip
- Analytics Dashboard: https://marketing.untrapd.com/downloads/analytics-dashboard.zip  
- Automation Scripts: https://marketing.untrapd.com/downloads/automation-scripts.zip
- Commercial License: https://marketing.untrapd.com/downloads/commercial-license.pdf

QUICK START:
1. Download all files above
2. Read the Quick Start PDF
3. Customize templates with your app details
4. Launch your first campaign
5. Track performance with analytics

CUSTOMER PORTAL:
https://marketing.untrapd.com/success.html?session=${customerData.sessionId}

NEED HELP?
Email: hello@untrapd.com
Response time: 4-6 hours
Refund policy: 30-day guarantee

ORDER DETAILS:
Order ID: ${customerData.sessionId}
Amount: $${customerData.amount}
Date: ${new Date().toLocaleDateString()}

UntrapD | https://marketing.untrapd.com
  `;
}

// Record sale for analytics
async function recordSale(saleData) {
  // Store sale data for revenue dashboard
  // This could integrate with your analytics service, database, or Google Analytics
  
  console.log('Recording sale:', {
    sessionId: saleData.sessionId,
    email: saleData.email,
    amount: saleData.amount,
    timestamp: saleData.timestamp
  });
  
  // Example: Send to Google Analytics via Measurement Protocol
  // Or store in database for revenue dashboard
  
  return true;
}